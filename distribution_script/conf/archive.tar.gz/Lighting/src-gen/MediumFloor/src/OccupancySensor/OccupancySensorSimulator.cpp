#include "OccupancySensorSimulator.h"

OccupancySensorSimulator::OccupancySensorSimulator(string fmuPath, string tmpDir, string name) :
    actorXPosition(0.0),
    actorYPosition(0.0),
    occupied(false)
    ,FmuWrapper(fmuPath, tmpDir, name)
    
{
    this->init();
}

void OccupancySensorSimulator::init() {
    changedAttributes.emplace("actorXPosition");
    changedAttributes.emplace("actorYPosition");
    changedAttributes.emplace("occupied");
}

void OccupancySensorSimulator::updateAttributeValues() {
    _actorXPosition = actorXPosition;
    try {
        actorXPosition = getReal(ACTORXPOSITION_NAME);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    }
    if (_actorXPosition != actorXPosition)
        changedAttributes.emplace("actorXPosition");
    _actorYPosition = actorYPosition;
    try {
        actorYPosition = getReal(ACTORYPOSITION_NAME);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    }
    if (_actorYPosition != actorYPosition)
        changedAttributes.emplace("actorYPosition");
    _occupied = occupied;
    try {
        occupied = getBool(OCCUPIED_NAME);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    }
    if (_occupied != occupied)
        changedAttributes.emplace("occupied");
}

double OccupancySensorSimulator::getActorXPosition() {
    return actorXPosition;
}
void OccupancySensorSimulator::setActorXPosition(double actorXPosition) {
    if (actorXPosition != this->actorXPosition)
        changedAttributes.emplace("actorXPosition");
    this->actorXPosition = actorXPosition;
    try {
        setReal(ACTORXPOSITION_NAME, actorXPosition);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    };
}


double OccupancySensorSimulator::getActorYPosition() {
    return actorYPosition;
}
void OccupancySensorSimulator::setActorYPosition(double actorYPosition) {
    if (actorYPosition != this->actorYPosition)
        changedAttributes.emplace("actorYPosition");
    this->actorYPosition = actorYPosition;
    try {
        setReal(ACTORYPOSITION_NAME, actorYPosition);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    };
}


bool OccupancySensorSimulator::getOccupied() {
    return occupied;
}
void OccupancySensorSimulator::setOccupied(bool occupied) {
    if (occupied != this->occupied)
        changedAttributes.emplace("occupied");
    this->occupied = occupied;
    try {
        setBool(OCCUPIED_NAME, occupied);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    };
}

