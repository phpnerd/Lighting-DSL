#include "BasicRoomControllerFederate.h"

BasicRoomControllerFederate::BasicRoomControllerFederate(string fmuModel, string tmpDir, string name, double stepSize) :
        stepSize(stepSize),
        sim(new BasicRoomControllerSimulator(fmuModel, tmpDir, name)),
        federate::federate() {}
    
void BasicRoomControllerFederate::init() {
    try {
      sim->finishModelInit();
    } catch (string& errorMessage) {
      wcerr << "Error: " << errorMessage.c_str() << endl;
    }
    publishOnlyChanges = true;
    federate::init();
}

void BasicRoomControllerFederate::initVariables(string initArg0, string initArg1, string initArg2, string initArg3) {
	try {
		if (initArg0 != "nil")
    		sim->setReal("OccupiedHoldTime", stod(initArg0));
		if (initArg1 != "nil")
    		sim->setReal("OccupiedLevel", stod(initArg1));
		if (initArg2 != "nil")
    		sim->setReal("VacantHoldTime", stod(initArg2));
		if (initArg3 != "nil")
    		sim->setReal("VacantLevel", stod(initArg3));
    } catch (string& errorMessage) {
      	wcerr << "Error: " << errorMessage.c_str() << endl;
    }
}

void BasicRoomControllerFederate::publish() {
    publishedAttributes["occupied"] = PublishedAttribute("occupied");
    publishedAttributes["setpoint"] = PublishedAttribute("setpoint");
    federate::publish();
}

void BasicRoomControllerFederate::timeAdvanceGrantListener(long double time) {
    sim->advanceTime(time);
    sim->updateAttributeValues();
    setPublishedChangedState(sim->getChangedAttributes());
    publishAttributeValues(getLbts());
    wcout << time << ": " << federateName.c_str() << " { occupied: " << sim->getOccupied() << ", setpoint: " << sim->getSetpoint() << " }" << endl;
}

void BasicRoomControllerFederate::receiveInteraction(InteractionClassHandle icHandle, ParameterHandleValueMap attributes, long double time) {

}

void BasicRoomControllerFederate::run() {
    while(!isStopped && (!hasStopTime || (hasStopTime && stopTime > fed->federateTime)))
    	advanceNextMessage(stepSize);
}

void BasicRoomControllerFederate::initialiseHandles() {
    objectClassHandles["Actor"] = rti->getObjectClassHandle(L"HLAobjectRoot.Actor");
    attributeHandles["Actor"]["xPosition"] = rti->getAttributeHandle(objectClassHandles["Actor"], L"xPosition");
    attributeHandles["Actor"]["yPosition"] = rti->getAttributeHandle(objectClassHandles["Actor"], L"yPosition");
    objectClassHandles["BasicRoomController"] = rti->getObjectClassHandle(L"HLAobjectRoot.BasicRoomController");
    objectClassHandle = objectClassHandles["BasicRoomController"];
    attributeHandles["BasicRoomController"]["occupied"] = rti->getAttributeHandle(objectClassHandles["BasicRoomController"], L"occupied");
    attributeHandles["BasicRoomController"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["BasicRoomController"], L"setpoint");
    objectClassHandles["CorridorController"] = rti->getObjectClassHandle(L"HLAobjectRoot.CorridorController");
    attributeHandles["CorridorController"]["activity"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"activity");
    attributeHandles["CorridorController"]["relatedActivity"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"relatedActivity");
    attributeHandles["CorridorController"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"setpoint");
    objectClassHandles["DimmableLight"] = rti->getObjectClassHandle(L"HLAobjectRoot.DimmableLight");
    attributeHandles["DimmableLight"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["DimmableLight"], L"setpoint");
    attributeHandles["DimmableLight"]["power"] = rti->getAttributeHandle(objectClassHandles["DimmableLight"], L"power");
    objectClassHandles["OccupancySensor"] = rti->getObjectClassHandle(L"HLAobjectRoot.OccupancySensor");
    attributeHandles["OccupancySensor"]["actorXPosition"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"actorXPosition");
    attributeHandles["OccupancySensor"]["actorYPosition"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"actorYPosition");
    attributeHandles["OccupancySensor"]["occupied"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"occupied");
    wcout << "Initialised handles" << endl;
}

void BasicRoomControllerFederate::publishAttributeValues(long double time) {
    AttributeHandleValueMap attributes;
    attributeValues["occupied"] = HLAboolean(sim->getOccupied()).encode();
    attributeValues["setpoint"] = HLAfloat64BE(sim->getSetpoint()).encode();
    federate::publishAttributeValues(time);
}

void BasicRoomControllerFederate::updateAttributeValues() {
    pair<bool, bool> _occupied;
    pair<bool, double> _setpoint;
    for (auto &attribute : subscribedAttributes) {
        if (!attribute.isRead()) {
            if (attribute.getTarget() == "occupied") {
                occupiedCache[attribute.getSourceReference().getRefName()] = toType<bool>(attribute.getData());
                _occupied.first = true;
            }
            if (attribute.getTarget() == "setpoint") {
                _setpoint.second = toType<double>(attribute.getData());
                _setpoint.first = true;
            }
        }
    }
    
    if (_occupied.first) {
        _occupied.second = mapValues<string, bool>(occupiedCache, [&](bool x, bool y) {
            return x || y;
        });
        sim->setOccupied(_occupied.second);
    }
    if (_setpoint.first) {
        sim->setSetpoint(_setpoint.second);
    }
}

void BasicRoomControllerFederate::setAttribute(string attribute, string value) {
    if (attribute == "occupied")
        sim->setOccupied(fromString<bool>(value));
    if (attribute == "setpoint")
        sim->setSetpoint(fromString<double>(value));
}

void BasicRoomControllerFederate::setAttribute(string attribute, VariableLengthData data) {
    if (attribute == "occupied")
        sim->setOccupied(toType<bool>(data));
    if (attribute == "setpoint")
        sim->setSetpoint(toType<double>(data));
}

VariableLengthData BasicRoomControllerFederate::getAttribute(string attribute) {
    if (attribute == "occupied")
        return toVLD(sim->getOccupied());
    if (attribute == "setpoint")
        return toVLD(sim->getSetpoint());
}
