#include <iostream>
#include <cstdlib>
#include <csignal>
#include "../OccupancySensor/OccupancySensorFederate.h"

using namespace std;

OccupancySensorFederate* occupancySensorFederate;

void signal_handler(int signal) {
    if (signal == SIGINT || signal == SIGTERM) {
        occupancySensorFederate->stop();
        delete occupancySensorFederate;
        exit(0);
    }
}

int main(int argc, char *argv[]) {
    if (signal(SIGINT, signal_handler) == SIG_ERR)
        wcerr << "Failed to register signal_handler for SIGINT" << endl;
    if (signal(SIGTERM, signal_handler) == SIG_ERR)
        wcerr << "Failed to register signal handler for SIGTERM" << endl;
    
    if (argc < 20) {
        wcout << "Invalid number of arguments; expected 19: [topology] [federateName] [fmuModel] [tmpDir] [modelName] [stepSize] [lookahead] [rtiAddress] [scenario | nil] [faultScenario | nil] [initThreshold] [initBounded_rangeRange] [initBounded_rangeOrigin0] [initBounded_rangeOrigin1] [initBounded_rangeBounds0] [initBounded_rangeBounds1] [initBounded_rangeBounds2] [initBounded_rangeBounds3] [initIntegrate4Initial]" << endl;
        return -1;
    }
    
    string topology = argv[1];
    string federateName = argv[2];
    string fmuModel = argv[3];
    string tmpDir = argv[4];
    string modelName = argv[5];
    double stepSize = stod(argv[6]);
    double lookahead = stod(argv[7]);
    string rtiAddress = argv[8];
    string scenario = argv[9];
    string faultScenario = argv[10];
    
    OccupancySensorFederate* occupancySensorFederate = new OccupancySensorFederate(fmuModel, tmpDir, modelName, stepSize);
    occupancySensorFederate->initVariables(argv[11], argv[12], argv[13], argv[14], argv[15], argv[16], argv[17], argv[18], argv[19]);
    occupancySensorFederate->setConfig(federateName, "fom.xml", rtiAddress, topology, scenario, faultScenario);
    ((federate*)occupancySensorFederate)->init(true, lookahead);
    occupancySensorFederate->run();
    occupancySensorFederate->stop();
    delete occupancySensorFederate;
    return 0;
}
