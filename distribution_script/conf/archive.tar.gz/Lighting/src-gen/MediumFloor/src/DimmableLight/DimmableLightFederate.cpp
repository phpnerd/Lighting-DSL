#include "DimmableLightFederate.h"

DimmableLightFederate::DimmableLightFederate(string fmuModel, string tmpDir, string name, double stepSize) :
        stepSize(stepSize),
        sim(new DimmableLightSimulator(fmuModel, tmpDir, name)),
        federate::federate() {}
    
void DimmableLightFederate::init() {
    try {
      sim->finishModelInit();
    } catch (string& errorMessage) {
      wcerr << "Error: " << errorMessage.c_str() << endl;
    }
    publishOnlyChanges = true;
    federate::init();
}

void DimmableLightFederate::initVariables(string initArg0, string initArg1) {
	try {
		if (initArg0 != "nil")
    		sim->setReal("Gain.K", stod(initArg0));
		if (initArg1 != "nil")
    		sim->setReal("Integrate.initial", stod(initArg1));
    } catch (string& errorMessage) {
      	wcerr << "Error: " << errorMessage.c_str() << endl;
    }
}

void DimmableLightFederate::publish() {
    publishedAttributes["power"] = PublishedAttribute("power");
    federate::publish();
}

void DimmableLightFederate::timeAdvanceGrantListener(long double time) {
    sim->advanceTime(time);
    sim->updateAttributeValues();
    setPublishedChangedState(sim->getChangedAttributes());
    publishAttributeValues(getLbts());
    wcout << time << ": " << federateName.c_str() << " { setpoint: " << sim->getSetpoint() << ", power: " << sim->getPower() << " }" << endl;
}

void DimmableLightFederate::receiveInteraction(InteractionClassHandle icHandle, ParameterHandleValueMap attributes, long double time) {

}

void DimmableLightFederate::run() {
    while(!isStopped && (!hasStopTime || (hasStopTime && stopTime > fed->federateTime)))
    	advanceNextMessage(stepSize);
}

void DimmableLightFederate::initialiseHandles() {
    objectClassHandles["Actor"] = rti->getObjectClassHandle(L"HLAobjectRoot.Actor");
    attributeHandles["Actor"]["xPosition"] = rti->getAttributeHandle(objectClassHandles["Actor"], L"xPosition");
    attributeHandles["Actor"]["yPosition"] = rti->getAttributeHandle(objectClassHandles["Actor"], L"yPosition");
    objectClassHandles["BasicRoomController"] = rti->getObjectClassHandle(L"HLAobjectRoot.BasicRoomController");
    attributeHandles["BasicRoomController"]["occupied"] = rti->getAttributeHandle(objectClassHandles["BasicRoomController"], L"occupied");
    attributeHandles["BasicRoomController"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["BasicRoomController"], L"setpoint");
    objectClassHandles["CorridorController"] = rti->getObjectClassHandle(L"HLAobjectRoot.CorridorController");
    attributeHandles["CorridorController"]["activity"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"activity");
    attributeHandles["CorridorController"]["relatedActivity"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"relatedActivity");
    attributeHandles["CorridorController"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"setpoint");
    objectClassHandles["DimmableLight"] = rti->getObjectClassHandle(L"HLAobjectRoot.DimmableLight");
    objectClassHandle = objectClassHandles["DimmableLight"];
    attributeHandles["DimmableLight"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["DimmableLight"], L"setpoint");
    attributeHandles["DimmableLight"]["power"] = rti->getAttributeHandle(objectClassHandles["DimmableLight"], L"power");
    objectClassHandles["OccupancySensor"] = rti->getObjectClassHandle(L"HLAobjectRoot.OccupancySensor");
    attributeHandles["OccupancySensor"]["actorXPosition"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"actorXPosition");
    attributeHandles["OccupancySensor"]["actorYPosition"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"actorYPosition");
    attributeHandles["OccupancySensor"]["occupied"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"occupied");
    wcout << "Initialised handles" << endl;
}

void DimmableLightFederate::publishAttributeValues(long double time) {
    AttributeHandleValueMap attributes;
    attributeValues["power"] = HLAfloat64BE(sim->getPower()).encode();
    federate::publishAttributeValues(time);
}

void DimmableLightFederate::updateAttributeValues() {
    pair<bool, double> _setpoint;
    for (auto &attribute : subscribedAttributes) {
        if (!attribute.isRead()) {
            if (attribute.getTarget() == "setpoint") {
                _setpoint.second = toType<double>(attribute.getData());
                _setpoint.first = true;
            }
        }
    }
    
    if (_setpoint.first) {
        sim->setSetpoint(_setpoint.second);
    }
}

void DimmableLightFederate::setAttribute(string attribute, string value) {
    if (attribute == "setpoint")
        sim->setSetpoint(fromString<double>(value));
    if (attribute == "power")
        sim->setPower(fromString<double>(value));
}

void DimmableLightFederate::setAttribute(string attribute, VariableLengthData data) {
    if (attribute == "setpoint")
        sim->setSetpoint(toType<double>(data));
    if (attribute == "power")
        sim->setPower(toType<double>(data));
}

VariableLengthData DimmableLightFederate::getAttribute(string attribute) {
    if (attribute == "setpoint")
        return toVLD(sim->getSetpoint());
    if (attribute == "power")
        return toVLD(sim->getPower());
}
