#ifndef BASICROOMCONTROLLERSIMULATOR_H
#define BASICROOMCONTROLLERSIMULATOR_H

#include <map>
#include <fmuWrapper.h>

class BasicRoomControllerSimulator : public FmuWrapper {

public:
	BasicRoomControllerSimulator(string fmuFile, string tmpDir, string name);
    void updateAttributeValues() override;
    bool getOccupied();
    void setOccupied(bool occupied);
    double getSetpoint();
    void setSetpoint(double setpoint);
    
protected:
    void init();

private:
    string OCCUPIED_NAME = "occupied";
    bool _occupied;
    bool occupied;
    string SETPOINT_NAME = "setpoint";
    double _setpoint;
    double setpoint;

};


#endif BASICROOMCONTROLLERSIMULATOR_H
