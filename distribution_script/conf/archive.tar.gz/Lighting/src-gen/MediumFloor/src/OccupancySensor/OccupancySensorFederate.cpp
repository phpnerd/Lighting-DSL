#include "OccupancySensorFederate.h"

OccupancySensorFederate::OccupancySensorFederate(string fmuModel, string tmpDir, string name, double stepSize) :
        stepSize(stepSize),
        sim(new OccupancySensorSimulator(fmuModel, tmpDir, name)),
        federate::federate() {}
    
void OccupancySensorFederate::init() {
    try {
      sim->finishModelInit();
    } catch (string& errorMessage) {
      wcerr << "Error: " << errorMessage.c_str() << endl;
    }
    publishOnlyChanges = true;
    federate::init();
}

void OccupancySensorFederate::initVariables(string initArg0, string initArg1, string initArg2, string initArg3, string initArg4, string initArg5, string initArg6, string initArg7, string initArg8) {
	try {
		if (initArg0 != "nil")
    		sim->setReal("threshold", stod(initArg0));
		if (initArg1 != "nil")
    		sim->setReal("bounded_range.range", stod(initArg1));
		if (initArg2 != "nil")
    		sim->setReal("bounded_range.origin[0]", stod(initArg2));
		if (initArg3 != "nil")
    		sim->setReal("bounded_range.origin[1]", stod(initArg3));
		if (initArg4 != "nil")
    		sim->setReal("bounded_range.bounds[0]", stod(initArg4));
		if (initArg5 != "nil")
    		sim->setReal("bounded_range.bounds[1]", stod(initArg5));
		if (initArg6 != "nil")
    		sim->setReal("bounded_range.bounds[2]", stod(initArg6));
		if (initArg7 != "nil")
    		sim->setReal("bounded_range.bounds[3]", stod(initArg7));
		if (initArg8 != "nil")
    		sim->setReal("Integrate4.initial", stod(initArg8));
    } catch (string& errorMessage) {
      	wcerr << "Error: " << errorMessage.c_str() << endl;
    }
}

void OccupancySensorFederate::publish() {
    publishedAttributes["occupied"] = PublishedAttribute("occupied");
    federate::publish();
}

void OccupancySensorFederate::timeAdvanceGrantListener(long double time) {
    sim->advanceTime(time);
    sim->updateAttributeValues();
    setPublishedChangedState(sim->getChangedAttributes());
    publishAttributeValues(getLbts());
    wcout << time << ": " << federateName.c_str() << " { actorXPosition: " << sim->getActorXPosition() << ", actorYPosition: " << sim->getActorYPosition() << ", occupied: " << sim->getOccupied() << " }" << endl;
}

void OccupancySensorFederate::receiveInteraction(InteractionClassHandle icHandle, ParameterHandleValueMap attributes, long double time) {

}

void OccupancySensorFederate::run() {
    while(!isStopped && (!hasStopTime || (hasStopTime && stopTime > fed->federateTime)))
    	advanceNextMessage(stepSize);
}

void OccupancySensorFederate::initialiseHandles() {
    objectClassHandles["Actor"] = rti->getObjectClassHandle(L"HLAobjectRoot.Actor");
    attributeHandles["Actor"]["xPosition"] = rti->getAttributeHandle(objectClassHandles["Actor"], L"xPosition");
    attributeHandles["Actor"]["yPosition"] = rti->getAttributeHandle(objectClassHandles["Actor"], L"yPosition");
    objectClassHandles["BasicRoomController"] = rti->getObjectClassHandle(L"HLAobjectRoot.BasicRoomController");
    attributeHandles["BasicRoomController"]["occupied"] = rti->getAttributeHandle(objectClassHandles["BasicRoomController"], L"occupied");
    attributeHandles["BasicRoomController"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["BasicRoomController"], L"setpoint");
    objectClassHandles["CorridorController"] = rti->getObjectClassHandle(L"HLAobjectRoot.CorridorController");
    attributeHandles["CorridorController"]["activity"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"activity");
    attributeHandles["CorridorController"]["relatedActivity"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"relatedActivity");
    attributeHandles["CorridorController"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"setpoint");
    objectClassHandles["DimmableLight"] = rti->getObjectClassHandle(L"HLAobjectRoot.DimmableLight");
    attributeHandles["DimmableLight"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["DimmableLight"], L"setpoint");
    attributeHandles["DimmableLight"]["power"] = rti->getAttributeHandle(objectClassHandles["DimmableLight"], L"power");
    objectClassHandles["OccupancySensor"] = rti->getObjectClassHandle(L"HLAobjectRoot.OccupancySensor");
    objectClassHandle = objectClassHandles["OccupancySensor"];
    attributeHandles["OccupancySensor"]["actorXPosition"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"actorXPosition");
    attributeHandles["OccupancySensor"]["actorYPosition"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"actorYPosition");
    attributeHandles["OccupancySensor"]["occupied"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"occupied");
    wcout << "Initialised handles" << endl;
}

void OccupancySensorFederate::publishAttributeValues(long double time) {
    AttributeHandleValueMap attributes;
    attributeValues["occupied"] = HLAboolean(sim->getOccupied()).encode();
    federate::publishAttributeValues(time);
}

void OccupancySensorFederate::updateAttributeValues() {
    pair<bool, double> _actorXPosition;
    pair<bool, double> _actorYPosition;
    for (auto &attribute : subscribedAttributes) {
        if (!attribute.isRead()) {
            if (attribute.getTarget() == "actorXPosition") {
                _actorXPosition.second = toType<double>(attribute.getData());
                _actorXPosition.first = true;
            }
            if (attribute.getTarget() == "actorYPosition") {
                _actorYPosition.second = toType<double>(attribute.getData());
                _actorYPosition.first = true;
            }
        }
    }
    
    if (_actorXPosition.first) {
        sim->setActorXPosition(_actorXPosition.second);
    }
    if (_actorYPosition.first) {
        sim->setActorYPosition(_actorYPosition.second);
    }
}

void OccupancySensorFederate::setAttribute(string attribute, string value) {
    if (attribute == "actorXPosition")
        sim->setActorXPosition(fromString<double>(value));
    if (attribute == "actorYPosition")
        sim->setActorYPosition(fromString<double>(value));
    if (attribute == "occupied")
        sim->setOccupied(fromString<bool>(value));
}

void OccupancySensorFederate::setAttribute(string attribute, VariableLengthData data) {
    if (attribute == "actorXPosition")
        sim->setActorXPosition(toType<double>(data));
    if (attribute == "actorYPosition")
        sim->setActorYPosition(toType<double>(data));
    if (attribute == "occupied")
        sim->setOccupied(toType<bool>(data));
}

VariableLengthData OccupancySensorFederate::getAttribute(string attribute) {
    if (attribute == "actorXPosition")
        return toVLD(sim->getActorXPosition());
    if (attribute == "actorYPosition")
        return toVLD(sim->getActorYPosition());
    if (attribute == "occupied")
        return toVLD(sim->getOccupied());
}
