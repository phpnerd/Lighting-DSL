#ifndef DIMMABLELIGHTSIMULATOR_H
#define DIMMABLELIGHTSIMULATOR_H

#include <map>
#include <fmuWrapper.h>

class DimmableLightSimulator : public FmuWrapper {

public:
	DimmableLightSimulator(string fmuFile, string tmpDir, string name);
    void updateAttributeValues() override;
    double getSetpoint();
    void setSetpoint(double setpoint);
    double getPower();
    void setPower(double power);
    
protected:
    void init();

private:
    string SETPOINT_NAME = "setpoint";
    double _setpoint;
    double setpoint;
    string POWER_NAME = "power";
    double _power;
    double power;

};


#endif DIMMABLELIGHTSIMULATOR_H
