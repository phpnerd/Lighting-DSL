#ifndef DimmableLightFEDERATE_H
#define DimmableLightFEDERATE_H

#include <federate.h>
#include "DimmableLightSimulator.h"

class DimmableLightFederate : public federate {
public:
    DimmableLightFederate(string fmuModel, string tmpDir, string name, double stepSize);
    void run() override;
    void init() override;
    void publish() override;
    void initVariables(string initArg0, string initArg1);
    void receiveInteraction(InteractionClassHandle icHandle, ParameterHandleValueMap attributes, long double time) override;

protected:

private:
    DimmableLightSimulator* sim;
    double stepSize;
    
    
    void initialiseHandles() override;
    void publishAttributeValues(long double) override;
    void timeAdvanceGrantListener(long double time) override;
    void updateAttributeValues() override;
    void setAttribute(string, string) override;
    void setAttribute(string, VariableLengthData) override;
    VariableLengthData getAttribute(string) override;
};

#endif //DimmableLightFEDERATE_H
