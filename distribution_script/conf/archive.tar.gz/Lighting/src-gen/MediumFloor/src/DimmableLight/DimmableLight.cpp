#include <iostream>
#include <cstdlib>
#include <csignal>
#include "../DimmableLight/DimmableLightFederate.h"

using namespace std;

DimmableLightFederate* dimmableLightFederate;

void signal_handler(int signal) {
    if (signal == SIGINT || signal == SIGTERM) {
        dimmableLightFederate->stop();
        delete dimmableLightFederate;
        exit(0);
    }
}

int main(int argc, char *argv[]) {
    if (signal(SIGINT, signal_handler) == SIG_ERR)
        wcerr << "Failed to register signal_handler for SIGINT" << endl;
    if (signal(SIGTERM, signal_handler) == SIG_ERR)
        wcerr << "Failed to register signal handler for SIGTERM" << endl;
    
    if (argc < 13) {
        wcout << "Invalid number of arguments; expected 12: [topology] [federateName] [fmuModel] [tmpDir] [modelName] [stepSize] [lookahead] [rtiAddress] [scenario | nil] [faultScenario | nil] [initGainK] [initIntegrateInitial]" << endl;
        return -1;
    }
    
    string topology = argv[1];
    string federateName = argv[2];
    string fmuModel = argv[3];
    string tmpDir = argv[4];
    string modelName = argv[5];
    double stepSize = stod(argv[6]);
    double lookahead = stod(argv[7]);
    string rtiAddress = argv[8];
    string scenario = argv[9];
    string faultScenario = argv[10];
    
    DimmableLightFederate* dimmableLightFederate = new DimmableLightFederate(fmuModel, tmpDir, modelName, stepSize);
    dimmableLightFederate->initVariables(argv[11], argv[12]);
    dimmableLightFederate->setConfig(federateName, "fom.xml", rtiAddress, topology, scenario, faultScenario);
    ((federate*)dimmableLightFederate)->init(true, lookahead);
    dimmableLightFederate->run();
    dimmableLightFederate->stop();
    delete dimmableLightFederate;
    return 0;
}
