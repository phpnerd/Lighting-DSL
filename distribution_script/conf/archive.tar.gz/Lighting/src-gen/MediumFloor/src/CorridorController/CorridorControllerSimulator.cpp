#include "CorridorControllerSimulator.h"

CorridorControllerSimulator::CorridorControllerSimulator(string fmuPath, string tmpDir, string name) :
    activity(false),
    relatedActivity(false),
    setpoint(0.0)
    ,FmuWrapper(fmuPath, tmpDir, name)
    
{
    this->init();
}

void CorridorControllerSimulator::init() {
    changedAttributes.emplace("activity");
    changedAttributes.emplace("relatedActivity");
    changedAttributes.emplace("setpoint");
}

void CorridorControllerSimulator::updateAttributeValues() {
    _activity = activity;
    try {
        activity = getBool(ACTIVITY_NAME);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    }
    if (_activity != activity)
        changedAttributes.emplace("activity");
    _relatedActivity = relatedActivity;
    try {
        relatedActivity = getBool(RELATEDACTIVITY_NAME);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    }
    if (_relatedActivity != relatedActivity)
        changedAttributes.emplace("relatedActivity");
    _setpoint = setpoint;
    try {
        setpoint = getReal(SETPOINT_NAME);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    }
    if (_setpoint != setpoint)
        changedAttributes.emplace("setpoint");
}

bool CorridorControllerSimulator::getActivity() {
    return activity;
}
void CorridorControllerSimulator::setActivity(bool activity) {
    if (activity != this->activity)
        changedAttributes.emplace("activity");
    this->activity = activity;
    try {
        setBool(ACTIVITY_NAME, activity);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    };
}


bool CorridorControllerSimulator::getRelatedActivity() {
    return relatedActivity;
}
void CorridorControllerSimulator::setRelatedActivity(bool relatedActivity) {
    if (relatedActivity != this->relatedActivity)
        changedAttributes.emplace("relatedActivity");
    this->relatedActivity = relatedActivity;
    try {
        setBool(RELATEDACTIVITY_NAME, relatedActivity);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    };
}


double CorridorControllerSimulator::getSetpoint() {
    return setpoint;
}
void CorridorControllerSimulator::setSetpoint(double setpoint) {
    if (setpoint != this->setpoint)
        changedAttributes.emplace("setpoint");
    this->setpoint = setpoint;
    try {
        setReal(SETPOINT_NAME, setpoint);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    };
}

