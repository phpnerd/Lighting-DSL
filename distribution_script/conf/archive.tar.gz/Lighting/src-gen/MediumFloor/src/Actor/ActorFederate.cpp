#include "ActorFederate.h"

ActorFederate::ActorFederate(double stepSize) :
        stepSize(stepSize),
        federate::federate() {}
    
void ActorFederate::init() {
    publishOnlyChanges = true;
    federate::init();
}


void ActorFederate::publish() {
    publishedAttributes["xPosition"] = PublishedAttribute("xPosition");
    publishedAttributes["yPosition"] = PublishedAttribute("yPosition");
    federate::publish();
}

void ActorFederate::timeAdvanceGrantListener(long double time) {
    setPublishedChangedState(changedAttributes);
    changedAttributes.clear();
    publishAttributeValues(getLbts());
    wcout << time << ": " << federateName.c_str() << " { xPosition: " << xPosition << ", yPosition: " << yPosition << " }" << endl;
}

void ActorFederate::receiveInteraction(InteractionClassHandle icHandle, ParameterHandleValueMap attributes, long double time) {

}

void ActorFederate::run() {
    while(!isStopped && (!hasStopTime || (hasStopTime && stopTime > fed->federateTime)))
    	advanceTime(stepSize);
}

void ActorFederate::initialiseHandles() {
    objectClassHandles["Actor"] = rti->getObjectClassHandle(L"HLAobjectRoot.Actor");
    objectClassHandle = objectClassHandles["Actor"];
    attributeHandles["Actor"]["xPosition"] = rti->getAttributeHandle(objectClassHandles["Actor"], L"xPosition");
    attributeHandles["Actor"]["yPosition"] = rti->getAttributeHandle(objectClassHandles["Actor"], L"yPosition");
    objectClassHandles["BasicRoomController"] = rti->getObjectClassHandle(L"HLAobjectRoot.BasicRoomController");
    attributeHandles["BasicRoomController"]["occupied"] = rti->getAttributeHandle(objectClassHandles["BasicRoomController"], L"occupied");
    attributeHandles["BasicRoomController"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["BasicRoomController"], L"setpoint");
    objectClassHandles["CorridorController"] = rti->getObjectClassHandle(L"HLAobjectRoot.CorridorController");
    attributeHandles["CorridorController"]["activity"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"activity");
    attributeHandles["CorridorController"]["relatedActivity"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"relatedActivity");
    attributeHandles["CorridorController"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"setpoint");
    objectClassHandles["DimmableLight"] = rti->getObjectClassHandle(L"HLAobjectRoot.DimmableLight");
    attributeHandles["DimmableLight"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["DimmableLight"], L"setpoint");
    attributeHandles["DimmableLight"]["power"] = rti->getAttributeHandle(objectClassHandles["DimmableLight"], L"power");
    objectClassHandles["OccupancySensor"] = rti->getObjectClassHandle(L"HLAobjectRoot.OccupancySensor");
    attributeHandles["OccupancySensor"]["actorXPosition"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"actorXPosition");
    attributeHandles["OccupancySensor"]["actorYPosition"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"actorYPosition");
    attributeHandles["OccupancySensor"]["occupied"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"occupied");
    wcout << "Initialised handles" << endl;
}

void ActorFederate::publishAttributeValues(long double time) {
    AttributeHandleValueMap attributes;
    attributeValues["xPosition"] = HLAfloat64BE(xPosition).encode();
    attributeValues["yPosition"] = HLAfloat64BE(yPosition).encode();
    federate::publishAttributeValues(time);
}

void ActorFederate::updateAttributeValues() {
    for (auto &attribute : subscribedAttributes) {
        if (!attribute.isRead()) {
        }
    }
    
}

void ActorFederate::setAttribute(string attribute, string value) {
    if (attribute == "xPosition") {
        changedAttributes.emplace("xPosition");
        xPosition = fromString<double>(value);
    }
    if (attribute == "yPosition") {
        changedAttributes.emplace("yPosition");
        yPosition = fromString<double>(value);
    }
}

void ActorFederate::setAttribute(string attribute, VariableLengthData data) {
    if (attribute == "xPosition") {
        changedAttributes.emplace("xPosition");
        xPosition = toType<double>(data);
    }
    if (attribute == "yPosition") {
        changedAttributes.emplace("yPosition");
        yPosition = toType<double>(data);
    }
}

VariableLengthData ActorFederate::getAttribute(string attribute) {
    if (attribute == "xPosition")
        return toVLD(xPosition);
    if (attribute == "yPosition")
        return toVLD(yPosition);
}
