#ifndef CORRIDORCONTROLLERSIMULATOR_H
#define CORRIDORCONTROLLERSIMULATOR_H

#include <map>
#include <fmuWrapper.h>

class CorridorControllerSimulator : public FmuWrapper {

public:
	CorridorControllerSimulator(string fmuFile, string tmpDir, string name);
    void updateAttributeValues() override;
    bool getActivity();
    void setActivity(bool activity);
    bool getRelatedActivity();
    void setRelatedActivity(bool relatedActivity);
    double getSetpoint();
    void setSetpoint(double setpoint);
    
protected:
    void init();

private:
    string ACTIVITY_NAME = "activity";
    bool _activity;
    bool activity;
    string RELATEDACTIVITY_NAME = "relatedActivity";
    bool _relatedActivity;
    bool relatedActivity;
    string SETPOINT_NAME = "setpoint";
    double _setpoint;
    double setpoint;

};


#endif CORRIDORCONTROLLERSIMULATOR_H
