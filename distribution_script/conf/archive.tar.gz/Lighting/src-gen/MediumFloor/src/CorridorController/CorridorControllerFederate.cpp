#include "CorridorControllerFederate.h"

CorridorControllerFederate::CorridorControllerFederate(string fmuModel, string tmpDir, string name, double stepSize) :
        stepSize(stepSize),
        sim(new CorridorControllerSimulator(fmuModel, tmpDir, name)),
        federate::federate() {}
    
void CorridorControllerFederate::init() {
    try {
      sim->finishModelInit();
    } catch (string& errorMessage) {
      wcerr << "Error: " << errorMessage.c_str() << endl;
    }
    publishOnlyChanges = true;
    federate::init();
}

void CorridorControllerFederate::initVariables(string initArg0, string initArg1, string initArg2, string initArg3, string initArg4, string initArg5) {
	try {
		if (initArg0 != "nil")
    		sim->setReal("ActiveHoldTime", stod(initArg0));
		if (initArg1 != "nil")
    		sim->setReal("ActiveLevel", stod(initArg1));
		if (initArg2 != "nil")
    		sim->setReal("VacantHoldTime", stod(initArg2));
		if (initArg3 != "nil")
    		sim->setReal("VacantLevel", stod(initArg3));
		if (initArg4 != "nil")
    		sim->setReal("RelatedHoldTime", stod(initArg4));
		if (initArg5 != "nil")
    		sim->setReal("RelatedLevel", stod(initArg5));
    } catch (string& errorMessage) {
      	wcerr << "Error: " << errorMessage.c_str() << endl;
    }
}

void CorridorControllerFederate::publish() {
    publishedAttributes["activity"] = PublishedAttribute("activity");
    publishedAttributes["relatedActivity"] = PublishedAttribute("relatedActivity");
    publishedAttributes["setpoint"] = PublishedAttribute("setpoint");
    federate::publish();
}

void CorridorControllerFederate::timeAdvanceGrantListener(long double time) {
    sim->advanceTime(time);
    sim->updateAttributeValues();
    setPublishedChangedState(sim->getChangedAttributes());
    publishAttributeValues(getLbts());
    wcout << time << ": " << federateName.c_str() << " { activity: " << sim->getActivity() << ", relatedActivity: " << sim->getRelatedActivity() << ", setpoint: " << sim->getSetpoint() << " }" << endl;
}

void CorridorControllerFederate::receiveInteraction(InteractionClassHandle icHandle, ParameterHandleValueMap attributes, long double time) {

}

void CorridorControllerFederate::run() {
    while(!isStopped && (!hasStopTime || (hasStopTime && stopTime > fed->federateTime)))
    	advanceNextMessage(stepSize);
}

void CorridorControllerFederate::initialiseHandles() {
    objectClassHandles["Actor"] = rti->getObjectClassHandle(L"HLAobjectRoot.Actor");
    attributeHandles["Actor"]["xPosition"] = rti->getAttributeHandle(objectClassHandles["Actor"], L"xPosition");
    attributeHandles["Actor"]["yPosition"] = rti->getAttributeHandle(objectClassHandles["Actor"], L"yPosition");
    objectClassHandles["BasicRoomController"] = rti->getObjectClassHandle(L"HLAobjectRoot.BasicRoomController");
    attributeHandles["BasicRoomController"]["occupied"] = rti->getAttributeHandle(objectClassHandles["BasicRoomController"], L"occupied");
    attributeHandles["BasicRoomController"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["BasicRoomController"], L"setpoint");
    objectClassHandles["CorridorController"] = rti->getObjectClassHandle(L"HLAobjectRoot.CorridorController");
    objectClassHandle = objectClassHandles["CorridorController"];
    attributeHandles["CorridorController"]["activity"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"activity");
    attributeHandles["CorridorController"]["relatedActivity"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"relatedActivity");
    attributeHandles["CorridorController"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["CorridorController"], L"setpoint");
    objectClassHandles["DimmableLight"] = rti->getObjectClassHandle(L"HLAobjectRoot.DimmableLight");
    attributeHandles["DimmableLight"]["setpoint"] = rti->getAttributeHandle(objectClassHandles["DimmableLight"], L"setpoint");
    attributeHandles["DimmableLight"]["power"] = rti->getAttributeHandle(objectClassHandles["DimmableLight"], L"power");
    objectClassHandles["OccupancySensor"] = rti->getObjectClassHandle(L"HLAobjectRoot.OccupancySensor");
    attributeHandles["OccupancySensor"]["actorXPosition"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"actorXPosition");
    attributeHandles["OccupancySensor"]["actorYPosition"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"actorYPosition");
    attributeHandles["OccupancySensor"]["occupied"] = rti->getAttributeHandle(objectClassHandles["OccupancySensor"], L"occupied");
    wcout << "Initialised handles" << endl;
}

void CorridorControllerFederate::publishAttributeValues(long double time) {
    AttributeHandleValueMap attributes;
    attributeValues["activity"] = HLAboolean(sim->getActivity()).encode();
    attributeValues["relatedActivity"] = HLAboolean(sim->getRelatedActivity()).encode();
    attributeValues["setpoint"] = HLAfloat64BE(sim->getSetpoint()).encode();
    federate::publishAttributeValues(time);
}

void CorridorControllerFederate::updateAttributeValues() {
    pair<bool, bool> _activity;
    pair<bool, bool> _relatedActivity;
    pair<bool, double> _setpoint;
    for (auto &attribute : subscribedAttributes) {
        if (!attribute.isRead()) {
            if (attribute.getTarget() == "activity") {
                activityCache[attribute.getSourceReference().getRefName()] = toType<bool>(attribute.getData());
                _activity.first = true;
            }
            if (attribute.getTarget() == "relatedActivity") {
                relatedActivityCache[attribute.getSourceReference().getRefName()] = toType<bool>(attribute.getData());
                _relatedActivity.first = true;
            }
            if (attribute.getTarget() == "setpoint") {
                _setpoint.second = toType<double>(attribute.getData());
                _setpoint.first = true;
            }
        }
    }
    
    if (_activity.first) {
        _activity.second = mapValues<string, bool>(activityCache, [&](bool x, bool y) {
            return x || y;
        });
        sim->setActivity(_activity.second);
    }
    if (_relatedActivity.first) {
        _relatedActivity.second = mapValues<string, bool>(relatedActivityCache, [&](bool x, bool y) {
            return x || y;
        });
        sim->setRelatedActivity(_relatedActivity.second);
    }
    if (_setpoint.first) {
        sim->setSetpoint(_setpoint.second);
    }
}

void CorridorControllerFederate::setAttribute(string attribute, string value) {
    if (attribute == "activity")
        sim->setActivity(fromString<bool>(value));
    if (attribute == "relatedActivity")
        sim->setRelatedActivity(fromString<bool>(value));
    if (attribute == "setpoint")
        sim->setSetpoint(fromString<double>(value));
}

void CorridorControllerFederate::setAttribute(string attribute, VariableLengthData data) {
    if (attribute == "activity")
        sim->setActivity(toType<bool>(data));
    if (attribute == "relatedActivity")
        sim->setRelatedActivity(toType<bool>(data));
    if (attribute == "setpoint")
        sim->setSetpoint(toType<double>(data));
}

VariableLengthData CorridorControllerFederate::getAttribute(string attribute) {
    if (attribute == "activity")
        return toVLD(sim->getActivity());
    if (attribute == "relatedActivity")
        return toVLD(sim->getRelatedActivity());
    if (attribute == "setpoint")
        return toVLD(sim->getSetpoint());
}
