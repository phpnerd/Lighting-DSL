#ifndef CorridorControllerFEDERATE_H
#define CorridorControllerFEDERATE_H

#include <federate.h>
#include "CorridorControllerSimulator.h"

class CorridorControllerFederate : public federate {
public:
    CorridorControllerFederate(string fmuModel, string tmpDir, string name, double stepSize);
    void run() override;
    void init() override;
    void publish() override;
    void initVariables(string initArg0, string initArg1, string initArg2, string initArg3, string initArg4, string initArg5);
    void receiveInteraction(InteractionClassHandle icHandle, ParameterHandleValueMap attributes, long double time) override;

protected:

private:
    CorridorControllerSimulator* sim;
    double stepSize;
    
    map<string, bool> activityCache;
    map<string, bool> relatedActivityCache;
    
    void initialiseHandles() override;
    void publishAttributeValues(long double) override;
    void timeAdvanceGrantListener(long double time) override;
    void updateAttributeValues() override;
    void setAttribute(string, string) override;
    void setAttribute(string, VariableLengthData) override;
    VariableLengthData getAttribute(string) override;
};

#endif //CorridorControllerFEDERATE_H
