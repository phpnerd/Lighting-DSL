#include <iostream>
#include <cstdlib>
#include <csignal>
#include "../BasicRoomController/BasicRoomControllerFederate.h"

using namespace std;

BasicRoomControllerFederate* basicRoomControllerFederate;

void signal_handler(int signal) {
    if (signal == SIGINT || signal == SIGTERM) {
        basicRoomControllerFederate->stop();
        delete basicRoomControllerFederate;
        exit(0);
    }
}

int main(int argc, char *argv[]) {
    if (signal(SIGINT, signal_handler) == SIG_ERR)
        wcerr << "Failed to register signal_handler for SIGINT" << endl;
    if (signal(SIGTERM, signal_handler) == SIG_ERR)
        wcerr << "Failed to register signal handler for SIGTERM" << endl;
    
    if (argc < 15) {
        wcout << "Invalid number of arguments; expected 14: [topology] [federateName] [fmuModel] [tmpDir] [modelName] [stepSize] [lookahead] [rtiAddress] [scenario | nil] [faultScenario | nil] [initOccupiedHoldTime] [initOccupiedLevel] [initVacantHoldTime] [initVacantLevel]" << endl;
        return -1;
    }
    
    string topology = argv[1];
    string federateName = argv[2];
    string fmuModel = argv[3];
    string tmpDir = argv[4];
    string modelName = argv[5];
    double stepSize = stod(argv[6]);
    double lookahead = stod(argv[7]);
    string rtiAddress = argv[8];
    string scenario = argv[9];
    string faultScenario = argv[10];
    
    BasicRoomControllerFederate* basicRoomControllerFederate = new BasicRoomControllerFederate(fmuModel, tmpDir, modelName, stepSize);
    basicRoomControllerFederate->initVariables(argv[11], argv[12], argv[13], argv[14]);
    basicRoomControllerFederate->setConfig(federateName, "fom.xml", rtiAddress, topology, scenario, faultScenario);
    ((federate*)basicRoomControllerFederate)->init(true, lookahead);
    basicRoomControllerFederate->run();
    basicRoomControllerFederate->stop();
    delete basicRoomControllerFederate;
    return 0;
}
