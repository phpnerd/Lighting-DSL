#include "DimmableLightSimulator.h"

DimmableLightSimulator::DimmableLightSimulator(string fmuPath, string tmpDir, string name) :
    setpoint(0.0),
    power(0.0)
    ,FmuWrapper(fmuPath, tmpDir, name)
    
{
    this->init();
}

void DimmableLightSimulator::init() {
    changedAttributes.emplace("setpoint");
    changedAttributes.emplace("power");
}

void DimmableLightSimulator::updateAttributeValues() {
    _setpoint = setpoint;
    try {
        setpoint = getReal(SETPOINT_NAME);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    }
    if (_setpoint != setpoint)
        changedAttributes.emplace("setpoint");
    _power = power;
    try {
        power = getReal(POWER_NAME);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    }
    if (_power != power)
        changedAttributes.emplace("power");
}

double DimmableLightSimulator::getSetpoint() {
    return setpoint;
}
void DimmableLightSimulator::setSetpoint(double setpoint) {
    if (setpoint != this->setpoint)
        changedAttributes.emplace("setpoint");
    this->setpoint = setpoint;
    try {
        setReal(SETPOINT_NAME, setpoint);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    };
}


double DimmableLightSimulator::getPower() {
    return power;
}
void DimmableLightSimulator::setPower(double power) {
    if (power != this->power)
        changedAttributes.emplace("power");
    this->power = power;
    try {
        setReal(POWER_NAME, power);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    };
}

