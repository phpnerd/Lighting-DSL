#ifndef BasicRoomControllerFEDERATE_H
#define BasicRoomControllerFEDERATE_H

#include <federate.h>
#include "BasicRoomControllerSimulator.h"

class BasicRoomControllerFederate : public federate {
public:
    BasicRoomControllerFederate(string fmuModel, string tmpDir, string name, double stepSize);
    void run() override;
    void init() override;
    void publish() override;
    void initVariables(string initArg0, string initArg1, string initArg2, string initArg3);
    void receiveInteraction(InteractionClassHandle icHandle, ParameterHandleValueMap attributes, long double time) override;

protected:

private:
    BasicRoomControllerSimulator* sim;
    double stepSize;
    
    map<string, bool> occupiedCache;
    
    void initialiseHandles() override;
    void publishAttributeValues(long double) override;
    void timeAdvanceGrantListener(long double time) override;
    void updateAttributeValues() override;
    void setAttribute(string, string) override;
    void setAttribute(string, VariableLengthData) override;
    VariableLengthData getAttribute(string) override;
};

#endif //BasicRoomControllerFEDERATE_H
