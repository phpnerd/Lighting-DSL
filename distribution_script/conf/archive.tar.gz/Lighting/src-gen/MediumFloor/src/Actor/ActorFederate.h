#ifndef ActorFEDERATE_H
#define ActorFEDERATE_H

#include <federate.h>

class ActorFederate : public federate {
public:
    ActorFederate(double);
    void run() override;
    void init() override;
    void publish() override;
    void receiveInteraction(InteractionClassHandle icHandle, ParameterHandleValueMap attributes, long double time) override;

protected:

private:
    double stepSize;
    set<string> changedAttributes;
    double xPosition;
    double yPosition;
    
    
    void initialiseHandles() override;
    void publishAttributeValues(long double) override;
    void timeAdvanceGrantListener(long double time) override;
    void updateAttributeValues() override;
    void setAttribute(string, string) override;
    void setAttribute(string, VariableLengthData) override;
    VariableLengthData getAttribute(string) override;
};

#endif //ActorFEDERATE_H
