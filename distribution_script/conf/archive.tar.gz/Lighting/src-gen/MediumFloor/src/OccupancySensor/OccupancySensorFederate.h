#ifndef OccupancySensorFEDERATE_H
#define OccupancySensorFEDERATE_H

#include <federate.h>
#include "OccupancySensorSimulator.h"

class OccupancySensorFederate : public federate {
public:
    OccupancySensorFederate(string fmuModel, string tmpDir, string name, double stepSize);
    void run() override;
    void init() override;
    void publish() override;
    void initVariables(string initArg0, string initArg1, string initArg2, string initArg3, string initArg4, string initArg5, string initArg6, string initArg7, string initArg8);
    void receiveInteraction(InteractionClassHandle icHandle, ParameterHandleValueMap attributes, long double time) override;

protected:

private:
    OccupancySensorSimulator* sim;
    double stepSize;
    
    
    void initialiseHandles() override;
    void publishAttributeValues(long double) override;
    void timeAdvanceGrantListener(long double time) override;
    void updateAttributeValues() override;
    void setAttribute(string, string) override;
    void setAttribute(string, VariableLengthData) override;
    VariableLengthData getAttribute(string) override;
};

#endif //OccupancySensorFEDERATE_H
