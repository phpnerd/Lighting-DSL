#include "BasicRoomControllerSimulator.h"

BasicRoomControllerSimulator::BasicRoomControllerSimulator(string fmuPath, string tmpDir, string name) :
    occupied(false),
    setpoint(0.0)
    ,FmuWrapper(fmuPath, tmpDir, name)
    
{
    this->init();
}

void BasicRoomControllerSimulator::init() {
    changedAttributes.emplace("occupied");
    changedAttributes.emplace("setpoint");
}

void BasicRoomControllerSimulator::updateAttributeValues() {
    _occupied = occupied;
    try {
        occupied = getBool(OCCUPIED_NAME);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    }
    if (_occupied != occupied)
        changedAttributes.emplace("occupied");
    _setpoint = setpoint;
    try {
        setpoint = getReal(SETPOINT_NAME);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    }
    if (_setpoint != setpoint)
        changedAttributes.emplace("setpoint");
}

bool BasicRoomControllerSimulator::getOccupied() {
    return occupied;
}
void BasicRoomControllerSimulator::setOccupied(bool occupied) {
    if (occupied != this->occupied)
        changedAttributes.emplace("occupied");
    this->occupied = occupied;
    try {
        setBool(OCCUPIED_NAME, occupied);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    };
}


double BasicRoomControllerSimulator::getSetpoint() {
    return setpoint;
}
void BasicRoomControllerSimulator::setSetpoint(double setpoint) {
    if (setpoint != this->setpoint)
        changedAttributes.emplace("setpoint");
    this->setpoint = setpoint;
    try {
        setReal(SETPOINT_NAME, setpoint);
    } catch (string& errorMessage) {
        wcerr << "Error: " << errorMessage.c_str() << endl;
    };
}

