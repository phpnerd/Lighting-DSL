#ifndef OCCUPANCYSENSORSIMULATOR_H
#define OCCUPANCYSENSORSIMULATOR_H

#include <map>
#include <fmuWrapper.h>

class OccupancySensorSimulator : public FmuWrapper {

public:
	OccupancySensorSimulator(string fmuFile, string tmpDir, string name);
    void updateAttributeValues() override;
    double getActorXPosition();
    void setActorXPosition(double actorXPosition);
    double getActorYPosition();
    void setActorYPosition(double actorYPosition);
    bool getOccupied();
    void setOccupied(bool occupied);
    
protected:
    void init();

private:
    string ACTORXPOSITION_NAME = "x_position";
    double _actorXPosition;
    double actorXPosition;
    string ACTORYPOSITION_NAME = "y_position";
    double _actorYPosition;
    double actorYPosition;
    string OCCUPIED_NAME = "occupied";
    bool _occupied;
    bool occupied;

};


#endif OCCUPANCYSENSORSIMULATOR_H
