#include <iostream>
#include <cstdlib>
#include <csignal>
#include "../Actor/ActorFederate.h"

using namespace std;

ActorFederate* actorFederate;

void signal_handler(int signal) {
    if (signal == SIGINT || signal == SIGTERM) {
        actorFederate->stop();
        delete actorFederate;
        exit(0);
    }
}

int main(int argc, char *argv[]) {
    if (signal(SIGINT, signal_handler) == SIG_ERR)
        wcerr << "Failed to register signal_handler for SIGINT" << endl;
    if (signal(SIGTERM, signal_handler) == SIG_ERR)
        wcerr << "Failed to register signal handler for SIGTERM" << endl;
    
    if (argc < 8) {
        cout << "Invalid number of arguments; expected 7: [topology] [federateName] [stepSize] [lookahead] [rtiAddress] [scenario | nil] [faultScenario | nil]" << endl;
        return -1;
    }
    string topology = argv[1];
    string federateName = argv[2];
    double stepSize = stod(argv[3]);
    double lookahead = stod(argv[4]);
    string rtiAddress = argv[5];
    string scenario = argv[6];
    string faultScenario = argv[7];

    actorFederate = new ActorFederate(stepSize);
    actorFederate->setConfig(federateName, "fom.xml", rtiAddress, topology, scenario, faultScenario);
    ((federate*)actorFederate)->init(true, lookahead);
    actorFederate->run();
    actorFederate->stop();
    delete actorFederate;
    return 0;
}
